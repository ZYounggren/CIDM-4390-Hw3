using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
using Microsoft.Extensions.Logging;
using Microsoft.EntityFrameworkCore;
using CIDM_4390.Models;

namespace CIDM_4390.Pages.Products
{
    public class ProductModel : PageModel
    {
        private readonly ProductDbContext _context; 
        private readonly ILogger<ProductModel> _logger;
        public List<Product> Products {get; set;}

        public ProductModel(ProductDbContext context, ILogger<ProductModel> logger)
        {
            _context = context;
            _logger = logger;
        }

        public void OnGet()
        {
            Products = _context.products.ToList();
        }
    }
}