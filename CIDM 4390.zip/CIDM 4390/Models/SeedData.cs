using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.DependencyInjection;
using System;
using System.Linq;

namespace CIDM_4390.Models
{
    public static class SeedData
    {
        public static void Initialize(IServiceProvider serviceProvider)
        {
            using (var context = new ProductDbContext(
                serviceProvider.GetRequiredService<DbContextOptions<ProductDbContext>>()))
            {
                // Look for any blogs.
                if (context.products.Any())
                {
                    return; // DB has been seeded
                }
                
                context.products.AddRange(
                    new Product{
                        Name = "Apple Sauce",
                        price = 12.50m //ppm
                    },
                    new Product{
                        Name = "White Bread",
                        price = 1.20m
                    },
                    new Product{
                        Name = "Wheat Bread",
                        price = 2.40m
                    },
                    new Product{
                        Name = "Cheese Slices",
                        price = 2.90m
                    },
                    new Product{
                        Name = "Ham",
                        price = 4.17m
                    }
                );
                
                context.SaveChanges();
            }
        }
    }
}