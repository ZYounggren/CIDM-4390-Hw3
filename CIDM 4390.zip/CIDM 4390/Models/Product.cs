using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;

namespace CIDM_4390.Models
{
    public class Product
    {
        public int ProductID{get; set;}
        public string Name{get; set;}
        public decimal price{get; set;}
    }
}